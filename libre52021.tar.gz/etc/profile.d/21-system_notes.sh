#!/bin/sh
echo ""
echo " === System Notes ================================================="
[ -f /etc/banner.notes ] && cat /etc/banner.notes
echo ""
echo " = edit via http://thisnode.info/app/#/notes or /etc/banner.notes ="
echo ""
