#!/usr/bin/lua

local fs = require("nixio.fs")
local lan = require("lime.proto.lan")
local utils = require("lime.utils")
local network = require("lime.network")
local config = require("lime.config")

batadv = {}

batadv.configured = false
batadv.old_cfg_api = false
batadv.type_option = 'master'
batadv.ifc_proto = 'batadv_hardif'

function batadv.detect_old_cfg_api()
    return not fs.lstat("/lib/netifd/proto/batadv_hardif.sh")
end

function batadv.configure(args)
	if batadv.configured then return end
	batadv.configured = true

	local cfg_file = 'network'
	if batadv.detect_old_cfg_api() then
		batadv.old_cfg_api = true
		cfg_file = 'batman-adv'
		batadv.ifc_proto = 'batadv'
		batadv.type_option = 'mesh'
	end

	local uci = config.get_uci_cursor()

	if not batadv.old_cfg_api then
		uci:set(cfg_file, "bat0", "interface")
		uci:set(cfg_file, "bat0", "proto", "batadv")
	else
		uci:set(cfg_file, "bat0", "mesh")
	end

	uci:set(cfg_file, "bat0", "bridge_loop_avoidance", "1")
	uci:set(cfg_file, "bat0", "multicast_mode", "0")

	-- if anygw enabled disable DAT that doesn't play well with it
	-- and set gw_mode=client everywhere. Since there's no gw_mode=server, this makes bat0 never forward requests
	-- so a rogue DHCP server doesn't affect whole network (DHCP requests are always answered locally)
	for _,proto in pairs(config.get("network", "protocols")) do
		if proto == "anygw" then
			uci:set(cfg_file, "bat0", "distributed_arp_table", "0")
			uci:set(cfg_file, "bat0", "gw_mode", "client")
		end
	end
	uci:save(cfg_file)
	lan.setup_interface("bat0", nil)

	-- enable alfred on bat0 if installed
	if utils.is_installed("alfred") then
		uci:set("alfred", "alfred", "batmanif", "bat0")
		uci:save("alfred")
	end
end

function batadv.setup_interface(ifname, args)
	if not args["specific"] then
		if ifname:match("^wlan%d+.ap") then return end
	end

	local vlanId = args[2] or "%N1"
	local vlanProto = args[3] or "8021ad"
	local nameSuffix = args[4] or "_batadv"
	local mtu = 1532

	if not tonumber(vlanId) then vlanId = 29 + (utils.applyNetTemplate10(vlanId) - 13) % 256 end

	local owrtInterfaceName, _, owrtDeviceName = network.createVlanIface(ifname, vlanId, nameSuffix, vlanProto)

	local uci = config.get_uci_cursor()
	uci:set("network", owrtInterfaceName, "proto", batadv.ifc_proto)
	uci:set("network", owrtInterfaceName, batadv.type_option, "bat0")

	if ifname:match("^eth") then
		mtu = network.MTU_ETH_WITH_VLAN
	end

	local id = utils.get_id(ifname)
	local vMacaddr = network.primary_mac();
	vMacaddr[1] = "02"
	vMacaddr[2] = id[2]
	vMacaddr[3] = id[3]
	uci:set("network", owrtDeviceName, "macaddr", table.concat(vMacaddr, ":"))

	uci:set("network", owrtDeviceName, "mtu", mtu)
	uci:save("network")
end


return batadv
